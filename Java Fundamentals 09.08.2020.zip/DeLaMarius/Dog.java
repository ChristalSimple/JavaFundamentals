package DeLaMarius;

public class Dog
{
    public int varsta;
    public String nume;

    public void latra()
    {
        System.out.println("Cainele cu numele:" + nume +
                " a latrat: Woof woof");
    }
}
