package DeLaMarius;

public class Casa
{
}
