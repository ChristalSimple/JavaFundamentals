//09.08.2020
package Java.Fundamentals.Ziua1;

public class Casa
{
}
