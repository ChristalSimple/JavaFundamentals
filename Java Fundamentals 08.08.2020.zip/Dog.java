public class Dog
{
    int a, b;
    String greutate;
}

// Pseudo-cod
//public class int[]
//        {
//                int length = 5;
//        }

//public class List
//{
//    Dog[] dogs = new Dog[2];
//}

//class Cat
//{
//    Dog dog1 = d1;
//}